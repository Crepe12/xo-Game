Molodo-font
240 characters
recommended size 1.4x
uppercase characters only

Install
Copy "Data" folder into your game directory
should look like this:
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Molodo-font.ttf
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Mod.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Controller.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Keyboard.Fonts.xaml
..\Baldur's Gate 3\bin\bg3.exe
..\Baldur's Gate 3\Launcher\LariLauncher.exe

Uninstall
Remove files
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Molodo-font.ttf
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Mod.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Controller.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Keyboard.Fonts.xaml