Bosk Test
531 characters
recommended size 1.3x

Install
Copy "Data" folder into your game directory
should look like this:
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Bosk Test.otf
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Mod.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Controller.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Keyboard.Fonts.xaml
..\Baldur's Gate 3\bin\bg3.exe
..\Baldur's Gate 3\Launcher\LariLauncher.exe

Uninstall
Remove files
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Bosk Test.otf
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Mod.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Controller.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Keyboard.Fonts.xaml