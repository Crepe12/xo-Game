sizes names are relative to original (approximately)
0.6 means lower
1.6 means bigger

Install
Select one of the sizes and copy "Data" folder into your game directory
should look like this:
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Mod.FontSizes.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledExtraLarge.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledExtraLarge_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledLarge.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledLarge_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledMedium.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledMedium_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledMinimal.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledMinimal_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledSmall.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledSmall_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\DefaultTheme.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\DefaultTheme_c.Fonts.xaml
..\Baldur's Gate 3\bin\bg3.exe
..\Baldur's Gate 3\Launcher\LariLauncher.exe

Uninstall
Remove files
..\Baldur's Gate 3\Data\Public\Game\GUI\FontsMod\Mod.FontSizes.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledExtraLarge.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledExtraLarge_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledLarge.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledLarge_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledMedium.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledMedium_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledMinimal.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledMinimal_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledSmall.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\Scaling\ScaledSmall_c.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\DefaultTheme.Fonts.xaml
..\Baldur's Gate 3\Data\Public\Game\GUI\Theme\DefaultTheme_c.Fonts.xaml